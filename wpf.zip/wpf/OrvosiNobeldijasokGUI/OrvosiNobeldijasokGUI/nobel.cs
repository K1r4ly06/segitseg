﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrvosiNobeldijasokGUI
{
    internal class nobel
    {
        public int ev { get; set; }
        public string nev { get; set; }
        public string szulhal { get; set; }
        public string orszag { get; set; }

        public nobel(string s)
        {
            string[] t = s.Split(';');
            ev = int.Parse(t[0]);
            nev = t[1];
            szulhal = t[2];
            orszag = t[3];
        }
    }
}
