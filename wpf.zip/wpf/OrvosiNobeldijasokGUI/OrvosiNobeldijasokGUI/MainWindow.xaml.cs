﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OrvosiNobeldijasokGUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<nobel> li = new List<nobel>();

        void general()
        {
            string[] t = File.ReadAllLines("orvosi_nobeldijak.txt");
            foreach (var e in t.Skip(1)) li.Add(new nobel(e));
        }

        public MainWindow()
        {
            general();
            InitializeComponent();
        }

        private void adatment_Click(object sender, RoutedEventArgs e)
        {
            if (eves.Text == "" || neves.Text == "" || szulh.Text == "" || orszag.Text == "")
            {
                MessageBox.Show("Töltsön ki minden mezőt!"); return;
            }
            if (int.Parse(eves.Text.ToString()) < 1989) MessageBox.Show("Hiba! Az évszám nem megfelelő!");

            try
            {
                string tartalom = $"Év;Név;SzületésHalálozás;Országkód\n" +
                        $"{eves.Text};{neves.Text};{szulh.Text};{orszag.Text}";

                File.WriteAllText("uj_dijazott.txt", tartalom);

                eves.Text = "";
                neves.Text = ""; 
                szulh.Text = "";
                orszag.Text = "";

            }
            catch
            {
                MessageBox.Show("Hiba az állomány írásánál");
            }

        }
    }
}
