﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace sudokuGUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void elle_Click(object sender, RoutedEventArgs e)
        {
            int meret = int.Parse(merete.Text);
            int kezd = kezdo.Text.Count();

            if (kezd > meret * meret)
                MessageBox.Show($"A feladvány hosszú: törlendő {kezd - meret * meret} számjegy!");
            
            if (kezd < meret * meret)
                MessageBox.Show($"„A feladvány rövid: kell még {meret * meret - kezd} számjegy!");
            
            if (kezd == meret * meret) 
                MessageBox.Show("A feladvány megfelelő hosszúságú!");
        }

        private void minusz_Click(object sender, RoutedEventArgs e)
        {
            if (int.Parse(merete.Text) != 4) merete.Text = $"{int.Parse(merete.Text) - 1}";
        }

        private void plusz_Click(object sender, RoutedEventArgs e)
        {
            if (int.Parse(merete.Text) != 9) merete.Text = $"{int.Parse(merete.Text) + 1}";
        }

        private void kezdo_TextChanged_1(object sender, TextChangedEventArgs e)
        {
            hossz.Content = $"Hossz: {kezdo.Text.Count()}";
        }
    }
}
