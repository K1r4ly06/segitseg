﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hegyekdoli
{
    internal class HegyekMo
    {
        public string hegynev;
        public string hegyseg;
        public int magassag;


        public HegyekMo(string sor)
        {
            string[] t = sor.Split(';');
            hegynev = t[0];
            hegyseg = t[1];
            magassag = int.Parse(t[2]);
        }
    }
}
