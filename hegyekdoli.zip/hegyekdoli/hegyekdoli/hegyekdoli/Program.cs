﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace hegyekdoli
{
    internal class Program
    {
        List<HegyekMo>lista = new List<HegyekMo>();

        void beolvasas()
        {
            string[] t = File.ReadAllLines("HegyekMo.txt", Encoding.Default);
            foreach (string e in t.Skip(1))
            {
                lista.Add(new HegyekMo(e));
            }
        }

        void feladat3()
        {
            Console.WriteLine($"3. feladat: Hegycsúcsok száma: {lista.Count()} db");
        }

        void feladat4()
        {
            var atl = lista.Average(a => a.magassag);
            Console.WriteLine($"4. feladat: Hegycsúcsok átlagos magassága: {atl} m");
        }
        
        void feladat5()
        {
            Console.WriteLine("5. feladat: A legmagasabb hegycsúcs adatai:");
            var kivalaszt = lista.OrderByDescending(a => a.magassag).First();
            Console.WriteLine($"\tNév: {kivalaszt.hegynev}");
            Console.WriteLine($"\tHegység: {kivalaszt.hegyseg}");
            Console.WriteLine($"\tMagasság: {kivalaszt.magassag} m");
        }

        void feladat6()
        {
            Console.Write("6. feladat: Kérek egy magasságot: ");
            var beolvasas = Console.ReadLine();
            var megnezzuk = lista.Where(a => a.hegyseg == "Börzsöny" & a.magassag > int.Parse(beolvasas));
            if (megnezzuk.Count() > 0)
            {
                Console.WriteLine($"Van {beolvasas}m-nél magasabb hegycsúcs a Börzsönyben!");
            }
            else
            {
                Console.WriteLine($"Nincs {beolvasas}m-nél magasabb hegycsúcs a Börzsönyben!");
            }
        }

        void feladat7()
        {
            var kival = lista.Where(a => a.magassag * 3.280839895 > 3000).Count();
            if (kival > 0)
            {
                Console.WriteLine($"7. feladat: 3000 lábnál magasabb hegycsúcsok száma: {kival}");
            }
        }

        void feladat8()
        {
            Console.WriteLine("8. feladat: Hegység statisztika:");

            var statisztika = lista.GroupBy(a => a.hegyseg).Select(a => new
            {
                hegyseg = a.Key,
                db = a.Count()
            });
            foreach (var e in statisztika)
            {
                Console.WriteLine($"\t{e.hegyseg} - {e.db} db");
            }
        }

        void feladat9()
        {
            Console.WriteLine("9. feladat: bukk-videk.txt");

            double atvaltasertek = 3.280839895;
            List<string> listabukk = new List<string>();

            listabukk.Add("Hegycsúcs neve;Magasság láb");
            
            var ahol = lista.Where(a => a.hegyseg == "Bükk-vidék");
            foreach (var e in ahol)
            {
                if (Math.Round(e.magassag * atvaltasertek, 1)
                    .ToString()
                    .EndsWith(".0"))
                {
                    listabukk.Add($"{e.hegynev};{Math.Round(e.magassag * atvaltasertek, 0)}");
                }
                else
                {
                    listabukk.Add($"{e.hegynev};{Math.Round(e.magassag * atvaltasertek, 1)}");
                }
            }
            File.WriteAllLines("bukk-videk.txt", listabukk);
        }
        Program()
        {
            beolvasas();
            feladat3();
            feladat4();
            feladat5();
            feladat6();
            feladat7();
            feladat8();
            feladat9();
        }
        static void Main(string[] args)
        {
            new Program();
            Console.ReadKey();
        }
    }
}
