const express    = require('express');
const DataModule = require('./datamodule');
const app        = express();
const port       = 3000;
const header1    = 'Content-Type';
const header2    = 'application/json; charset=UTF-8';

app.use(express.static('public'));               
const DM = new DataModule( {} );                

app.post('/teszt',(req, res) => {   
  var sql =`select (2*21) as RESULT;`;
  sendJson_toFrontend (res, sql);         
});

async function sendJson_toFrontend (res, sql) {
  var json_data = await DM.runQuery(sql);
  // console.log(json_data);
  res.set(header1, header2);
  res.send(json_data);
  res.end();
}

app.listen(port, function () { console.log(`progi app listening at http://localhost:${port}`); });

app.post('/lista1', (req, res) => {
  var sql =`SELECT DISTINCT OSZTALY FROM diakok`;
  sendJson_toFrontend (res, sql); 
});

app.post('/tanulok1', (req, res) => {
  var oszt = (req.query.oszt? req.query.oszt: "");
  var sql =`SELECT NEV, EMAIL, OSZTALY, ID_DIAK FROM diakok WHERE OSZTALY = '${oszt}' `;
  sendJson_toFrontend (res, sql); 
});

app.post('/kepkivalaszt', (req, res) => {
  var id = (req.query.id? req.query.id: "");
  var sql =`SELECT ID_DIAK, FOTO, NEV, OSZTALY, EMAIL, TELEPULES FROM diakok WHERE ID_DIAK = ${id}`;
  sendJson_toFrontend (res, sql); 
});

app.post('/kurzusok', (req, res) => { 
  var id = (req.query.id? req.query.id: "");
  var sql =`SELECT tantargy, tanarok.nev AS 'Tanar', oraszam, diakok.nev AS 'Diak', diakok.ID_DIAK
            FROM kurzusok
            INNER JOIN tanarok ON kurzusok.ID_TANAR = tanarok.ID_TANAR
            INNER JOIN tantargyak ON kurzusok.ID_TANTARGY = tantargyak.ID_TANTARGY
            INNER JOIN diakok ON kurzusok.ID_DIAK = diakok.ID_DIAK
            WHERE diakok.ID_DIAK = ${id}
            ORDER BY tantargy`;
  sendJson_toFrontend (res, sql); 
});