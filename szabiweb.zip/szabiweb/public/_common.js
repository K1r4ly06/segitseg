
function strEscape(s) { return s.replaceAll("'","").replaceAll("\"","").replaceAll("\t","").replaceAll("\\","").replaceAll("`","");}

function ajax_get( urlsor, hova, tipus, aszinkron ) {         // html oldalak beszúrására használjuk
  $.ajax({url: urlsor, type:"get", async:aszinkron, cache:false, dataType:tipus===0?'html':'json',
      beforeSend:function(xhr)   {  },
      success:   function(data)  { $(hova).html(data); },
      error:     function(jqXHR, textStatus, errorThrown) {console.log(jqXHR.responseText);},
      complete:  function()      {  }  
  });
  return true;
};

function ajax_post( urlsor, tipus  ) {                        // json restapi-hoz használjuk  (tipus=0--> html; tipus=1--> json)
  var s = "";
  $.ajax({url: urlsor, type:"post", async:false, cache:false, dataType:tipus===0?'html':'json',
      beforeSend:function(xhr)   {  },
      success:   function(data)  { s = data; },
      error:     function(jqXHR, textStatus, errorThrown) {console.log(jqXHR.responseText);},
      complete:  function()      {  }
  });
  return s;
};  