﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fuvaradoli
{
    internal class Program
    {
        List<Fuvar> lista = new List<Fuvar>();

        void beolvasas()
        {
            string[] t = File.ReadAllLines("fuvar.csv", Encoding.UTF8);
            foreach (string e in t.Skip(1))
            {
                lista.Add(new Fuvar(e));
            }
        }

        void feladat3()
        {
            var db = lista.Select(a => a.megtavolsag).Count();
            Console.WriteLine($"3. feladat: {db} fuvar");
        }

        void feladat4()
        {
            var vane = lista.Where(a => a.taxiazonosito == 6185);
            var osszeg = vane.Sum(a => a.vitel);
            Console.WriteLine($"4. feladat: {vane.Count()} fuvar alatt: {osszeg:n2}$");
        }

        void feladat5()
        {
            Console.WriteLine($"5. feladat:");

            var modokselect = lista.GroupBy(a => a.fizetesmod).Select(a => new
                {
                    milyenfizetes = a.Key,
                    db = a.Count()
                });
            foreach (var a in modokselect)
            {
                Console.WriteLine($"\t{a.milyenfizetes}: {a.db} fuvar");
            }
        }

        void feladat6()
        {
            var osszesmegtettkm = lista.Sum(a => a.megtavolsag * 1.6);
            Console.WriteLine($"6. feladat: {osszesmegtettkm:n2}km");
        }

        void feladat7()
        {
            Console.WriteLine("7. feladat: Leghosszabb fuvar:");

            var leghosszabb = lista.OrderByDescending(a => a.utazasido).First();

            Console.WriteLine($"\tFuvar hossza: {leghosszabb.utazasido} másodperc");
            Console.WriteLine($"\tTaxi azonosító: {leghosszabb.taxiazonosito}");
            Console.WriteLine($"\tMegtett távolság: {leghosszabb.megtavolsag} km");
            Console.WriteLine($"\tViteldíj: {leghosszabb.vitel}$");
        }

        void feladat8()
        {
            Console.WriteLine("8. feladat: hibak.txt");
            var listab = lista
            .Where(a => a.megtavolsag == 0 && a.vitel > 0 && a.utazasido > 0)
            .OrderBy(a => a.indulasidopont);
          
            string t = "taxi_id;indulas;idotartam;tavolsag;viteldij;borravalo;fizetes_modja\n";

            foreach (var e in listab)
            {
                t += $"{e.taxiazonosito};{e.indulasidopont};{e.utazasido};{e.megtavolsag};{e.vitel};{e.borravalo};{e.fizetesmod}\n";
            }

            File.WriteAllText("hibak.txt", t);
        }
        Program()
        {
            beolvasas();
            feladat3();
            feladat4();
            feladat5();
            feladat6();
            feladat7();
            feladat8();
        }
        static void Main(string[] args)
        {
            new Program();
            Console.ReadKey();
        }
    }
}
