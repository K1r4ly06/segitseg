﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fuvaradoli
{
    internal class Fuvar
    {
        public int taxiazonosito;
        public string indulasidopont;
        public int utazasido;
        public double megtavolsag;
        public double vitel;
        public double borravalo;
        public string fizetesmod;

        public Fuvar(string sor)
        {
            string[] t = sor.Split(';');
            this.taxiazonosito = int.Parse(t[0]);
            this.indulasidopont = t[1];
            this.utazasido = int.Parse(t[2]);
            this.megtavolsag = double.Parse(t[3]);
            this.vitel = double.Parse(t[4]);
            this.borravalo = double.Parse(t[5]);
            this.fizetesmod = t[6];
        }
    }
}