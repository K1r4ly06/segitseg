const express    = require('express');
const DataModule = require('./datamodule');
const app        = express();
const port       = 3000;
const header1    = 'Content-Type';
const header2    = 'application/json; charset=UTF-8';

app.use(express.static('public'));               // public/index.html a def.
const DM = new DataModule( {} );                

app.post('/osztalyok', (req, res) => {           // osztályok listája
  var sql = `select OSZTALY FROM diakok group by OSZTALY order by OSZTALY;`;                   
  sendJson_toFrontend (res, sql); 
});

app.post('/diakok/:osztaly', (req, res) => {     // osztályba járó diákok listája
  var sql = `select * FROM diakok where OSZTALY = "${req.params.osztaly}" order by NEV;`;                   
  sendJson_toFrontend (res, sql); 
});

app.post('/diak/:id_diak',(req, res) => {         // diák adatai
  var sql =`select * FROM diakok WHERE ID_DIAK = ${req.params.id_diak}`;
  sendJson_toFrontend (res, sql);         
});

app.post('/kurzusok/:id_diak',(req, res) => {    // diák kurzusai
  var sql =`SELECT TANTARGY, a.NEV AS TANAR, ORASZAM
            FROM kurzusok k
            INNER JOIN diakok d ON d.ID_DIAK = k.ID_DIAK
            INNER JOIN tantargyak t ON t.ID_TANTARGY = k.ID_TANTARGY
            INNER JOIN tanarok a ON a.ID_TANAR = k.ID_TANAR
            WHERE d.ID_DIAK =  ${req.params.id_diak}
            ORDER BY t.TANTARGY`;
  sendJson_toFrontend (res, sql);         
});

async function sendJson_toFrontend (res, sql) {
  var json_data = await DM.runQuery(sql);
  // console.log(json_data);
  res.set(header1, header2);
  res.send(json_data);
  res.end();
}

app.listen(port, function () { console.log(`progi app listening at http://localhost:${port}`); });