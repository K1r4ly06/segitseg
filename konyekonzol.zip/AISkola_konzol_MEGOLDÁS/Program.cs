﻿/*
 NÉV OSZTÁLY 
 Konzolos alkalmazás fejlesztés ---- Szoftverfejlesztő gyakorló fladatsor - [v: 2026.03]
 dotnet new console --use-program-main
 dotnet clean dotnet build dotnet run
*/

namespace aiskola_konzol;

class Program
{
    List<aiskola_tip> aiskola = new List<aiskola_tip>();
   
    public Program(string[] args)
    {
        double maxipenz = 0;
        String maxinev = "";
        String[] sorok = File.ReadAllLines("aiskola_konzol.txt");
        foreach (string sor in sorok)
        {
            aiskola.Add(new aiskola_tip(sor));
         Console.WriteLine(aiskola[^1].ToString()); // utolsó elem (C# 8+)
            if (maxipenz < aiskola[^1].PENZ) { maxipenz = aiskola[^1].PENZ;  maxinev = aiskola[^1].NEV; }
        }

        //  ----------- legtöbb osztálypénz -------
        Console.WriteLine($"A legtöbb osztálypénzt {maxinev}, ({maxipenz},-Ft) fizette be.");

        //-------------- osztálylétszámok  -------
        var fő_Osztályonként = aiskola
            .GroupBy(x => x.OSZTALY)
            .Select(g => new
            {
                OSZTALY = g.Key,
                FŐ      = g.Select(x => x.NEV).Distinct().Count()
            });
        foreach (var k in fő_Osztályonként) { Console.WriteLine($"{k.OSZTALY} : {k.FŐ} fő"); }

        //-------------- osztálypénz osztályonként -------
        var pénz_Osztályonként = aiskola
            .GroupBy(x => x.OSZTALY)
            .Select(g => new
            {
                OSZTALY   = g.Key,
                SZUMPÉNZ  = g.Sum(x => x.PENZ)
            });

        foreach (var k in pénz_Osztályonként) { Console.WriteLine($"{k.OSZTALY} : {k.SZUMPÉNZ:F2},-Ft"); }

        Console.WriteLine(aiskola[^1].ToString()); // utolsó diák (C# 8+)
        Console.WriteLine("---- Kilépés: ENTER -----");
        Console.ReadLine();
    }

    static void Main(string[] args)
    {
        Console.WriteLine("Konzolos alkalmazás fejlesztés ---- Szoftverfejlesztő szakmai vizsga - [v: 2026.03]");
        new Program(args);
    }
}
