﻿namespace aiskola_konzol
{
    class aiskola_tip
    {

        private static string telephely =  "ZALAEGERSZEG"
        ;
        public int ID_DIAK;
        public String NEV { get; set; }
        public String OM { get; set; }
        public String EMAIL { get; set; }
        public String FOTO { get; set; }
        public String OSZTALY { get; set; }
        public String TELEPULES { get; set; }
        public String SZULDATUM { get; set; }
        public double PENZ = 0;
        public bool BEJÁRÓ { get { return _bejáró(); } }
        private bool _bejáró() { return telephely.Equals(this.TELEPULES.ToUpper());  }

        public aiskola_tip(String sor)
        {
            String[] tömb = sor.Split('\t');                 // ID_DIAK	NEV	OM	EMAIL	FOTO	OSZTALY	TELEPULES	SZULDATUM	PENZ
            this.ID_DIAK = Convert.ToInt32(tömb[0]);
            this.NEV =tömb[1];
            this.OM =tömb[2];
            this.EMAIL =tömb[3];
            this.FOTO =tömb[4];
            this.OSZTALY =tömb[5];
            this.TELEPULES =tömb[6];
            this.SZULDATUM =tömb[7];
            this.PENZ = Convert.ToDouble(tömb[8]);
        }

        public override string ToString()
        {
            return String.Format("ID:{0} {1} OM:{2} OSZTALY:{3} TELEPÜLÉS:{4} SZÜL:{5} Osztálypénz:{6:F2},-Ft BEJÁRÓS:{7}",
                                 this.ID_DIAK,this.NEV ,this.OM,this.OSZTALY, 
                                 this.TELEPULES,this.SZULDATUM, this.PENZ, this.BEJÁRÓ   );
        }
    }
}
